# Remote IP Mapper

Remote IP Mapper is a fast Windows command-line network mapper written in modern C++.
It scans a `/24` IPv4 network using non-blocking Winsock TCP connections and reports responsive hosts, open ports, refused ports, optional reverse DNS names, and scan progress.

> Use this tool only on networks you own or have explicit permission to test.

## Features

- Modern C++17 project layout
- Object-oriented design
- Non-blocking Winsock TCP connect scanner
- Live console progress bar
- Repeat-scan menu after each run
- Reverse DNS lookup for responsive hosts
- CMake build support
- Static MSVC runtime configuration for easier distribution

## Project Layout

```text
remote-ip-mapper/
├── include/
│   └── remote_ip_mapper/
│       ├── IPAddress.hpp
│       ├── NetworkScanner.hpp
│       └── ConsoleUI.hpp
├── src/
│   ├── main.cpp
│   ├── IPAddress.cpp
│   ├── NetworkScanner.cpp
│   └── ConsoleUI.cpp
├── README.md
├── LICENSE
├── .gitignore
└── CMakeLists.txt
```

## Build Requirements

- Windows
- Visual Studio 2022 with C++ Desktop Development workload
- CMake 3.20 or newer
- C++17 compiler

## Build with CMake

From the project root:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

The executable will be created under:

```text
build/Release/remote_ip_mapper.exe
```

or, depending on your generator layout:

```text
build/bin/Release/remote_ip_mapper.exe
```

## Run

```powershell
remote_ip_mapper.exe
```

Or pass a default network on the command line:

```powershell
remote_ip_mapper.exe 192.168.1.0
```

The program scans host addresses `1` through `254` in the selected `/24` network.

Default scanned ports:

```text
445, 135, 3389, 80, 443, 22
```

## Example Output

```text
Scanning network 192.168.1.0...
[####################--------------------]  50.0%  762/1524 targets  Hosts found: 5

Scan Summary
--------------------------------------------------
Network: 192.168.1.0
Ports scanned: 445, 135, 3389, 80, 443, 22
Responsive hosts: 5
Elapsed time: 743 ms
```

## Current Limitations

- Windows/Winsock only
- `/24` networks only in this first version
- Host detection is TCP-response based
- Some firewalls may block or hide hosts

## Roadmap Ideas

- CIDR support such as `192.168.0.0/16`
- Automatic local subnet detection
- CSV/JSON export
- Configurable port list from command line
- GUI version
- Linux/macOS socket backend

## Author

Nathan A. Gerwig / GrumpyGrayBeard

## License

MIT License. See [LICENSE](LICENSE).
