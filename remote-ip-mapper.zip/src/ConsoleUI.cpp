#include "remote_ip_mapper/ConsoleUI.hpp"

#include "remote_ip_mapper/IPAddress.hpp"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <limits>

namespace remote_ip_mapper {
namespace {

uint32_t networkToHostOrder(uint32_t value)
{
    return ((value & 0x000000FFu) << 24) |
           ((value & 0x0000FF00u) << 8)  |
           ((value & 0x00FF0000u) >> 8)  |
           ((value & 0xFF000000u) >> 24);
}

} // namespace

std::string ConsoleUI::promptForNetwork(const std::string& defaultNetwork) const
{
    std::cout << "\n==================================================\n";
    std::cout << "Remote IP Mapper\n";
    std::cout << "==================================================\n";
    std::cout << "Enter the target network in IPv4 format.\n";
    std::cout << "Example: 192.168.1.0\n";
    std::cout << "Press Enter to use default [" << defaultNetwork << "]: ";

    std::string input;
    std::getline(std::cin, input);

    if (input.empty()) {
        return defaultNetwork;
    }

    return input;
}

void ConsoleUI::showProgress(size_t completedTargets, size_t totalTargets, size_t hostsFound) const
{
    double percent = totalTargets == 0
        ? 100.0
        : (100.0 * static_cast<double>(completedTargets) / static_cast<double>(totalTargets));

    if (percent > 100.0) {
        percent = 100.0;
    }

    constexpr int barWidth = 40;
    int filled = static_cast<int>((percent / 100.0) * barWidth);

    if (filled > barWidth) {
        filled = barWidth;
    }

    std::cout << "\r[";
    for (int i = 0; i < barWidth; ++i) {
        std::cout << (i < filled ? '#' : '-');
    }

    std::cout << "] "
              << std::fixed << std::setprecision(1)
              << std::setw(5) << percent << "%  "
              << completedTargets << "/" << totalTargets
              << " targets  Hosts found: " << hostsFound
              << "      ";

    std::cout.flush();

    if (completedTargets >= totalTargets) {
        std::cout << "\n";
    }
}

void ConsoleUI::printResults(const std::string& network,
                             const std::vector<uint16_t>& ports,
                             const NetworkScanner::ResultMap& results,
                             long long elapsedMilliseconds) const
{
    std::vector<uint32_t> addresses;
    addresses.reserve(results.size());

    for (const auto& pair : results) {
        addresses.push_back(pair.first);
    }

    std::sort(addresses.begin(), addresses.end(), [](uint32_t left, uint32_t right) {
        return networkToHostOrder(left) < networkToHostOrder(right);
    });

    std::cout << "\nScan Summary\n";
    std::cout << "--------------------------------------------------\n";
    std::cout << "Network: " << network << "\n";
    std::cout << "Ports scanned: ";

    for (size_t i = 0; i < ports.size(); ++i) {
        std::cout << ports[i];
        if (i + 1 < ports.size()) {
            std::cout << ", ";
        }
    }

    std::cout << "\nResponsive hosts: " << results.size() << "\n";
    std::cout << "Elapsed time: " << elapsedMilliseconds << " ms\n";

    std::cout << "\nScan Results\n";
    std::cout << "--------------------------------------------------\n";

    if (addresses.empty()) {
        std::cout << "No responsive hosts found.\n";
        return;
    }

    for (uint32_t ip : addresses) {
        const HostHit& host = results.at(ip);

        std::cout << IPAddress::toString(ip);
        if (!host.name.empty()) {
            std::cout << "  (" << host.name << ")";
        }
        std::cout << "\n";

        if (!host.openPorts.empty()) {
            std::cout << "  open:    ";
            for (uint16_t port : host.openPorts) {
                std::cout << port << " ";
            }
            std::cout << "\n";
        }

        if (!host.refusedPorts.empty()) {
            std::cout << "  refused: ";
            for (uint16_t port : host.refusedPorts) {
                std::cout << port << " ";
            }
            std::cout << "\n";
        }

        std::cout << "\n";
    }
}

bool ConsoleUI::askScanAgain() const
{
    while (true) {
        std::cout << "\nMenu\n";
        std::cout << "1. Scan another network\n";
        std::cout << "2. Quit\n";
        std::cout << "Enter choice: ";

        std::string choice;
        std::getline(std::cin, choice);

        if (choice == "1") {
            return true;
        }

        if (choice == "2") {
            return false;
        }

        std::cout << "Invalid selection. Please enter 1 or 2.\n";
    }
}

void ConsoleUI::printError(const std::string& message) const
{
    std::cerr << "Error: " << message << "\n";
}

} // namespace remote_ip_mapper
