#include "remote_ip_mapper/NetworkScanner.hpp"

#include "remote_ip_mapper/IPAddress.hpp"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#include <algorithm>
#include <chrono>
#include <stdexcept>

namespace remote_ip_mapper {
namespace {

using Clock = std::chrono::steady_clock;

struct Target {
    uint32_t ipNetworkByteOrder = 0;
    uint16_t portNetworkByteOrder = 0;
};

enum class ScanResult {
    Connected,
    Refused,
    TimedOut,
    Unreachable,
    Failed
};

struct InFlight {
    SOCKET socketHandle = INVALID_SOCKET;
    uint32_t ipNetworkByteOrder = 0;
    uint16_t portHostOrder = 0;
    Clock::time_point startTime;
};

void closeSocket(SOCKET socketHandle)
{
    if (socketHandle != INVALID_SOCKET) {
        closesocket(socketHandle);
    }
}

ScanResult classifyConnectResult(SOCKET socketHandle)
{
    int error = 0;
    int length = sizeof(error);

    if (getsockopt(socketHandle, SOL_SOCKET, SO_ERROR,
                   reinterpret_cast<char*>(&error), &length) != 0) {
        return ScanResult::Failed;
    }

    if (error == 0) {
        return ScanResult::Connected;
    }

    if (error == WSAECONNREFUSED) {
        return ScanResult::Refused;
    }

    if (error == WSAETIMEDOUT) {
        return ScanResult::TimedOut;
    }

    if (error == WSAEHOSTUNREACH || error == WSAENETUNREACH) {
        return ScanResult::Unreachable;
    }

    return ScanResult::Failed;
}

bool reverseDns(uint32_t ipNetworkByteOrder, std::string& outName)
{
    sockaddr_in socketAddress{};
    socketAddress.sin_family = AF_INET;
    socketAddress.sin_addr.S_un.S_addr = ipNetworkByteOrder;

    char host[NI_MAXHOST]{};
    int result = getnameinfo(reinterpret_cast<sockaddr*>(&socketAddress),
                             sizeof(socketAddress),
                             host,
                             static_cast<DWORD>(sizeof(host)),
                             nullptr,
                             0,
                             NI_NAMEREQD);

    if (result == 0) {
        outName = host;
        return true;
    }

    return false;
}

void sortAndDeduplicate(std::vector<uint16_t>& ports)
{
    std::sort(ports.begin(), ports.end());
    ports.erase(std::unique(ports.begin(), ports.end()), ports.end());
}

} // namespace

NetworkScanner::NetworkScanner(ScanConfig config)
    : config_(config)
{
    WSADATA winsockData{};
    if (WSAStartup(MAKEWORD(2, 2), &winsockData) != 0) {
        throw std::runtime_error("WSAStartup failed");
    }

    winsockStarted_ = true;
}

NetworkScanner::~NetworkScanner()
{
    if (winsockStarted_) {
        WSACleanup();
    }
}

const ScanConfig& NetworkScanner::config() const noexcept
{
    return config_;
}

NetworkScanner::ResultMap NetworkScanner::scanNetwork24(
    const std::string& network,
    const std::vector<uint16_t>& ports,
    ProgressCallback progressCallback) const
{
    uint32_t networkByteOrder = 0;
    if (!IPAddress::parseIPv4(network, networkByteOrder)) {
        throw std::invalid_argument("Invalid IPv4 network: " + network);
    }

    const auto addresses = IPAddress::makeRange24(networkByteOrder, 1, 254);

    std::vector<Target> targets;
    targets.reserve(addresses.size() * ports.size());

    for (uint32_t ip : addresses) {
        for (uint16_t port : ports) {
            targets.push_back(Target{ ip, htons(port) });
        }
    }

    const size_t totalTargets = targets.size();
    size_t launchedCount = 0;
    size_t completedCount = 0;

    ResultMap hits;
    std::vector<InFlight> inflight;
    inflight.reserve(config_.maxInflight);

    auto lastProgressUpdate = Clock::now();

    auto reportProgress = [&]() {
        if (progressCallback) {
            progressCallback(completedCount, totalTargets, hits.size());
        }
    };

    reportProgress();

    while (launchedCount < targets.size() || !inflight.empty()) {
        while (launchedCount < targets.size() && inflight.size() < config_.maxInflight) {
            const Target& target = targets[launchedCount++];

            SOCKET socketHandle = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            if (socketHandle == INVALID_SOCKET) {
                ++completedCount;
                continue;
            }

            u_long nonBlocking = 1;
            if (ioctlsocket(socketHandle, FIONBIO, &nonBlocking) != 0) {
                closeSocket(socketHandle);
                ++completedCount;
                continue;
            }

            BOOL flag = TRUE;
            setsockopt(socketHandle, IPPROTO_TCP, TCP_NODELAY,
                       reinterpret_cast<char*>(&flag), sizeof(flag));

            sockaddr_in socketAddress{};
            socketAddress.sin_family = AF_INET;
            socketAddress.sin_addr.S_un.S_addr = target.ipNetworkByteOrder;
            socketAddress.sin_port = target.portNetworkByteOrder;

            int connectResult = connect(socketHandle,
                                        reinterpret_cast<sockaddr*>(&socketAddress),
                                        sizeof(socketAddress));

            if (connectResult == 0) {
                uint16_t portHostOrder = ntohs(target.portNetworkByteOrder);
                HostHit& host = hits[target.ipNetworkByteOrder];
                host.up = true;
                host.openPorts.push_back(portHostOrder);
                closeSocket(socketHandle);
                ++completedCount;
                continue;
            }

            int winsockError = WSAGetLastError();
            if (winsockError != WSAEWOULDBLOCK &&
                winsockError != WSAEINPROGRESS &&
                winsockError != WSAEINVAL) {
                closeSocket(socketHandle);
                ++completedCount;
                continue;
            }

            inflight.push_back(InFlight{ socketHandle,
                                         target.ipNetworkByteOrder,
                                         static_cast<uint16_t>(ntohs(target.portNetworkByteOrder)),
                                         Clock::now() });
        }

        if (inflight.empty()) {
            continue;
        }

        std::vector<WSAPOLLFD> pollDescriptors;
        pollDescriptors.reserve(inflight.size());

        for (const InFlight& item : inflight) {
            WSAPOLLFD descriptor{};
            descriptor.fd = item.socketHandle;
            descriptor.events = POLLOUT;
            descriptor.revents = 0;
            pollDescriptors.push_back(descriptor);
        }

        int pollResult = WSAPoll(pollDescriptors.data(),
                                 static_cast<ULONG>(pollDescriptors.size()),
                                 config_.connectTimeoutMs);

        auto now = Clock::now();
        std::vector<InFlight> keep;
        keep.reserve(inflight.size());

        for (size_t i = 0; i < inflight.size(); ++i) {
            const InFlight& item = inflight[i];

            bool timedOut =
                std::chrono::duration_cast<std::chrono::milliseconds>(now - item.startTime).count()
                >= config_.overallTimeoutMs;

            bool ready =
                (pollResult > 0) &&
                (pollDescriptors[i].revents & (POLLOUT | POLLERR | POLLHUP));

            if (!ready && !timedOut) {
                keep.push_back(item);
                continue;
            }

            ScanResult result = timedOut
                ? ScanResult::TimedOut
                : classifyConnectResult(item.socketHandle);

            HostHit& host = hits[item.ipNetworkByteOrder];

            if (result == ScanResult::Connected) {
                host.up = true;
                host.openPorts.push_back(item.portHostOrder);
            }
            else if (result == ScanResult::Refused) {
                if (config_.treatRefusedAsUp) {
                    host.up = true;
                }
                host.refusedPorts.push_back(item.portHostOrder);
            }

            closeSocket(item.socketHandle);
            ++completedCount;
        }

        inflight.swap(keep);

        auto millisecondsSinceProgress =
            std::chrono::duration_cast<std::chrono::milliseconds>(now - lastProgressUpdate).count();

        if (millisecondsSinceProgress >= 200 || completedCount == totalTargets) {
            reportProgress();
            lastProgressUpdate = now;
        }
    }

    reportProgress();

    for (auto& pair : hits) {
        HostHit& host = pair.second;
        if (!host.up) {
            continue;
        }

        sortAndDeduplicate(host.openPorts);
        sortAndDeduplicate(host.refusedPorts);

        if (config_.doReverseDns) {
            reverseDns(pair.first, host.name);
        }
    }

    for (auto iterator = hits.begin(); iterator != hits.end();) {
        if (!iterator->second.up) {
            iterator = hits.erase(iterator);
        }
        else {
            ++iterator;
        }
    }

    return hits;
}

} // namespace remote_ip_mapper
