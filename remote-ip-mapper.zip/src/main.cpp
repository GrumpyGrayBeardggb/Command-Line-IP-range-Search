#include "remote_ip_mapper/ConsoleUI.hpp"
#include "remote_ip_mapper/NetworkScanner.hpp"

#include <chrono>
#include <exception>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char** argv)
{
    using Clock = std::chrono::steady_clock;
    using remote_ip_mapper::ConsoleUI;
    using remote_ip_mapper::NetworkScanner;
    using remote_ip_mapper::ScanConfig;

    try {
        ConsoleUI ui;

        ScanConfig config;
        config.connectTimeoutMs = 120;
        config.overallTimeoutMs = 450;
        config.maxInflight = 2048;
        config.treatRefusedAsUp = true;
        config.doReverseDns = true;

        NetworkScanner scanner(config);
        std::vector<uint16_t> ports = { 445, 135, 3389, 80, 443, 22 };

        std::string defaultNetwork = (argc >= 2) ? argv[1] : "192.168.1.0";
        bool running = true;

        while (running) {
            std::string network = ui.promptForNetwork(defaultNetwork);

            std::cout << "\nScanning network " << network << "...\n";

            auto start = Clock::now();
            auto results = scanner.scanNetwork24(
                network,
                ports,
                [&](size_t completed, size_t total, size_t hostsFound) {
                    ui.showProgress(completed, total, hostsFound);
                });
            auto stop = Clock::now();

            auto elapsedMilliseconds =
                std::chrono::duration_cast<std::chrono::milliseconds>(stop - start).count();

            ui.printResults(network, ports, results, elapsedMilliseconds);

            running = ui.askScanAgain();
            defaultNetwork = "192.168.1.0";
        }
    }
    catch (const std::exception& ex) {
        std::cerr << "Fatal error: " << ex.what() << "\n";
        std::cout << "Press Enter to exit...";
        std::cin.get();
        return 1;
    }

    return 0;
}
