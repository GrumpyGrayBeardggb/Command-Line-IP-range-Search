#include "remote_ip_mapper/IPAddress.hpp"

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>

namespace remote_ip_mapper {

bool IPAddress::parseIPv4(const std::string& input, uint32_t& outNetworkByteOrder)
{
    in_addr address{};
    if (inet_pton(AF_INET, input.c_str(), &address) == 1) {
        outNetworkByteOrder = address.S_un.S_addr;
        return true;
    }

    return false;
}

std::string IPAddress::toString(uint32_t ipNetworkByteOrder)
{
    in_addr address{};
    address.S_un.S_addr = ipNetworkByteOrder;

    char buffer[INET_ADDRSTRLEN]{};
    inet_ntop(AF_INET, &address, buffer, static_cast<socklen_t>(sizeof(buffer)));
    return buffer;
}

std::vector<uint32_t> IPAddress::makeRange24(uint32_t networkByteOrder,
                                             uint8_t startHost,
                                             uint8_t endHost)
{
    std::vector<uint32_t> addresses;

    if (startHost > endHost) {
        return addresses;
    }

    uint32_t networkHostOrder = ntohl(networkByteOrder);
    addresses.reserve(static_cast<size_t>(endHost - startHost + 1));

    for (uint32_t host = startHost; host <= endHost; ++host) {
        uint32_t ipHostOrder = (networkHostOrder & 0xFFFFFF00u) | (host & 0xFFu);
        addresses.push_back(htonl(ipHostOrder));
    }

    return addresses;
}

} // namespace remote_ip_mapper
