#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

namespace remote_ip_mapper {

struct HostHit {
    bool up = false;
    std::vector<uint16_t> openPorts;
    std::vector<uint16_t> refusedPorts;
    std::string name;
};

struct ScanConfig {
    int connectTimeoutMs = 120;
    int overallTimeoutMs = 450;
    size_t maxInflight = 2048;
    bool treatRefusedAsUp = true;
    bool doReverseDns = true;
};

class NetworkScanner {
public:
    using ResultMap = std::unordered_map<uint32_t, HostHit>;
    using ProgressCallback = std::function<void(size_t completedTargets,
                                                size_t totalTargets,
                                                size_t hostsFound)>;

    explicit NetworkScanner(ScanConfig config = {});
    ~NetworkScanner();

    NetworkScanner(const NetworkScanner&) = delete;
    NetworkScanner& operator=(const NetworkScanner&) = delete;

    ResultMap scanNetwork24(const std::string& network,
                            const std::vector<uint16_t>& ports,
                            ProgressCallback progressCallback = nullptr) const;

    const ScanConfig& config() const noexcept;

private:
    ScanConfig config_;
    bool winsockStarted_ = false;
};

} // namespace remote_ip_mapper
