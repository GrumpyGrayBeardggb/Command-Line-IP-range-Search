#pragma once

#include "remote_ip_mapper/NetworkScanner.hpp"

#include <cstdint>
#include <string>
#include <vector>

namespace remote_ip_mapper {

class ConsoleUI {
public:
    std::string promptForNetwork(const std::string& defaultNetwork) const;
    void showProgress(size_t completedTargets, size_t totalTargets, size_t hostsFound) const;
    void printResults(const std::string& network,
                      const std::vector<uint16_t>& ports,
                      const NetworkScanner::ResultMap& results,
                      long long elapsedMilliseconds) const;
    bool askScanAgain() const;
    void printError(const std::string& message) const;
};

} // namespace remote_ip_mapper
