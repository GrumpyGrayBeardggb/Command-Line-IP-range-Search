#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace remote_ip_mapper {

class IPAddress {
public:
    // Parses a dotted IPv4 string such as "192.168.1.0" into network byte order.
    static bool parseIPv4(const std::string& input, uint32_t& outNetworkByteOrder);

    // Converts an IPv4 address stored in network byte order into dotted string form.
    static std::string toString(uint32_t ipNetworkByteOrder);

    // Creates a simple /24 range from a base network address.
    // Example: 192.168.1.0 -> 192.168.1.1 through 192.168.1.254.
    static std::vector<uint32_t> makeRange24(uint32_t networkByteOrder,
                                             uint8_t startHost = 1,
                                             uint8_t endHost = 254);
};

} // namespace remote_ip_mapper
